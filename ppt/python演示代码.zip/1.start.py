print("hello world!")

# i = 10

# if i < 5:
#     print("1")
# else:
#     print(2)

# for i in range(5):
#     # print(i)
#     print("name:%s" % i)


# i = 0
# while i < 5:
#     print(i, "while")
#     i = i + 1

# i = 10
# j = 10.0

# a = "123"

# print(i, j, a)


# a = ["1", "2", "3"]

# for value in a:
#     print(value)

# d = {"host": "host1", "port": 100}

# for key in d:
#     print(key, d[key], d.get(key))


# f = open("1.py")
# print(f.read())
# f.close()


# f = open("tmp", "w")
# f.write("123\n1234")
# f.close()

# f = open("tmp")
# print(f.read())
# f.close()

# r = "1234\n12345\n435"
# with open("tmp", "w") as f:
#     f.write(r)

# with open("tmp", "r") as f:
#     a = f.read()

# print(a)
# print("---")
# for line in a.split("34"):
#     print(line)


# a = "name:%s"

# print("name:%s" % ("123"))
