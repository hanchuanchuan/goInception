# -*- coding: utf-8 -*-

import os

os.system("dir")
